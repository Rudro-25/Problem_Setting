#include <bits/stdc++.h>
using namespace std;

#define      PSB         push_back
#define      ll          long long
#define      FastIO      ios::sync_with_stdio(0);cin.tie(0); cout.tie(0);
constexpr ll mod = 1e9  + 7;
const ll N=3e5+5;

int main(){
  FastIO
  int n,h,k;
  cin>>n>>h>>k;
  vector<int> a(n);
  for(int i=0;i<n;i++) cin>>a[i];
  sort(a.begin(),a.end());
  int pos=n-1,ans=0;
  while(k && pos>=0){
    if(a[pos]<=h){
        --k; ans+=a[pos];
    }
    --pos;
  }
  cout<<ans<<endl;

  return 0;
}

