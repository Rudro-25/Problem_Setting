#include <bits/stdc++.h>
using namespace std;

#define      PSB         push_back
#define      ll          long long
#define      FastIO      ios::sync_with_stdio(0);cin.tie(0); cout.tie(0);
constexpr ll mod = 1e9  + 7;
const ll N=3e5+5;

ll cnt[N],val[N],wt[N];

ll max(ll a, ll b)
{
    return (a > b) ? a : b;
}
ll knapSack(ll W,ll n)
{
    ll i, w;
    ll K[n + 1][W + 1];
    for (i = 0; i <= n; i++)
    {
        for (w = 0; w <= W; w++)
        {
            if (i == 0 || w == 0)
                K[i][w] = 0;
            else if (wt[i - 1] <= w)
                K[i][w] = max(val[i - 1]
                          + K[i - 1][w - wt[i - 1]],
                          K[i - 1][w]);
            else
                K[i][w] = K[i - 1][w];
        }
    }
    return K[n][W];
}

int main(){
  FastIO
   ll n,W,a;
   cin>>n>>W;
   vector<ll> v;
   for(ll i=0;i<n;i++){
    cin>>a;
    cnt[a]++;
    if(cnt[a]==1) v.PSB(a);
   }
   ll len=v.size();
   sort(v.begin(),v.end());
   for(ll i=0;i<len;i++){
     wt[i]=v[i];
     val[i]=cnt[v[i]];
   }
   cout<<knapSack(W,n)<<endl;

  return 0;
}

