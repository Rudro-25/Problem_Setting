/*   --------------------
    |       LOSER        |
    |     ~NOOBOSS~      |
     --------------------
*/
#include <bits/stdc++.h>
using namespace std;
#define      mxx                 LLONG_MAX
#define      mnn                 LLONG_MIN
#define      Y()                 cout<< "YES" <<endl
#define      N()                 cout << "NO"<<endl
#define      endl                "\n"
#define      Ceil(x,y)           ((x+y-1)/y)
#define      sz(s)               (int)s.size()
#define      angle(x)            double(x * acos(-1) / 180.0)
#define      max_3(a,b,c)        max(a, max(b,c))
#define      min_3(a,b,c)        min(a, min(b,c))
#define      gcd(a,b)            __gcd(a,b)
#define      lcm(a,b)           (a*b)/gcd(a,b)
#define      loser               return 0
#define      ll                  long long
#define      PI                  acos(-1)
#define      mem(a,v)            memset(a,v,sizeof(a))
#define      all(v)              v.begin(),v.end()
#define      SORT(v)             sort(v.begin(),v.end())
#define      SRV(v)              sort(v.rbegin(),v.rend())
#define      REV(v)              reverse(v.begin(),v.end())
#define      B                   begin()
#define      E                   end()
#define      V                   vector
#define      F                   first
#define      S                   second
#define      PSB                 push_back
#define      MP                  make_pair
#define      flash               cout.flush()
#define      InTheNameOfGod      ios::sync_with_stdio(0);cin.tie(0); cout.tie(0);
constexpr ll MOD = 998244353;
constexpr ll mod = 1e9  + 7;
int dx[] = {0,0,1,-1};
int dy[] = {1,-1,0,0};
/*-----*/
#define bug1(a)  cerr<<a<<endl;
#define bug2(a,b)  cerr<<a<<" "<<b<<endl;
#define bug3(a,b,c)  cerr<<a<<" "<<b<<" "<<c<<endl;
/*----*/
const ll N=3e5+5;
vector<ll> adj[N];
ll power(ll n,ll p){if(p==0) return 1;if(p==1)return n;if(p%2)return power(n,p-1)*n;else{ll x=power(n,p/2);return x*x;}}
ll modpow(ll a,ll b,ll m){ll ans=1;while(b){if(b&1)ans=(ans*a)%m;b/=2;a=(a*a)%m;}return ans;}
ll nsum(ll num){return (num*(num+1))/2;}
void edge (ll u,ll v) {adj[u].PSB(v) ;adj[v].PSB(u);}
/*------------------START---------------------*/
ll cnt[N],mark[N];

/*-----*/
void solve(){
   ll n;
   string s;
   cin>>n;
   V<ll> a(n);
   for(ll i=0;i<n;i++){
    cin>>a[i];
    cnt[a[i]]++;
   }
   SORT(a);
   queue<ll> q;
   q.push(a[0]);
   mark[a[0]]=1;
   while(!q.empty()){
    ll now=q.front();
    //bug1(now);
    q.pop();
    for(ll i=1;i*i<=now;i++){
        if(now%i==0&&!mark[i]){
            if(cnt[i]){
                q.push(i); mark[i]=1;
            }
            ll bal=now/i;
            if(cnt[bal]&&!mark[bal]){
                q.push(bal); mark[bal]=1;
            }
        }

    }
        for(ll i=now;i<=a[n-1];i+=now){
            if(cnt[i]&&!mark[i]){
                q.push(i); mark[i]=1;
            }
        }

   }

   for(ll i=0;i<n;i++){
    if(!mark[a[i]]){
        N();
        //bug1(a[i]);
        return;
    }
   }
   Y();



   //cout << fixed << setprecision(10);
}
/*-----*/
int main(){
   InTheNameOfGod

   ll Test=1;
   //cin>>Test;
   while(Test--){
     solve();
    }
  loser;
}
///////   C O D I N G  I S  L I F E   ///////

/*
4
4 6 8 12
*/
